#!/usr/bin/env python3
"""Verify the D7(m), m=3,5, zero-set and rank certificates.

This verifier reconstructs the layer schedules from
``d7_m3_m5_zero_set_certificates.json`` and checks the local and global
root-flat obligations used in the manuscript.  When a rank-certificate JSON is
provided, it also checks the finite proof object for RF3:

    rho_{m,c}(R_c(w)) = rho_{m,c}(w) + 1  (mod m^6).

The checks performed are:

  zero-set certificate
    1. selector coverage on every zero set encountered in A_{7,m};
    2. row Latin condition for the non-constant layer;
    3. incoming exact-cover condition MC_7;
    4. bijectivity of every layer map P_{t,c};
    5. direct enumeration that each color return R_c is one m^6-cycle.

  rank certificate, if supplied
    6. metadata and constant-offset agreement with the zero-set certificate;
    7. every rank list is a permutation of {0,...,m^6-1};
    8. optional stored return maps match the reconstructed return maps;
    9. the rank-increment predicate holds for all states and colors.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, FrozenSet, Iterable, List, Mapping, Optional, Sequence, Tuple

D = 7
NONCONST_LAYER = 1
State = Tuple[int, ...]


class VerificationError(RuntimeError):
    """Raised when a certificate predicate fails."""


def root_states(m: int) -> List[State]:
    """Return A_{7,m} in the index order used by the rank certificate."""
    states: List[State] = []

    def rec(prefix: List[int], k: int) -> None:
        if k == D - 1:
            states.append(tuple(prefix + [(-sum(prefix)) % m]))
            return
        for x in range(m):
            rec(prefix + [x], k + 1)

    rec([], 0)
    return states


def add_q(w: State, i: int, m: int, sign: int = 1) -> State:
    """Add sign*q_i to w, where q_i=e_i-e_6 for i<6 and q_6=0."""
    if i == D - 1:
        return w
    ww = list(w)
    ww[i] = (ww[i] + sign) % m
    ww[D - 1] = (ww[D - 1] - sign) % m
    return tuple(ww)


def zero_set(w: State, m: int) -> FrozenSet[int]:
    return frozenset(i for i, x in enumerate(w) if x % m == 0)


def shift_set(Z: FrozenSet[int], c: int) -> FrozenSet[int]:
    return frozenset((i - c) % D for i in Z)


def as_int_dict(raw: Mapping[str, int]) -> Dict[int, int]:
    return {int(k): int(v) for k, v in raw.items()}


def load_selector(case: Mapping[str, object]) -> Dict[FrozenSet[int], int]:
    selector = {}
    for row in case["selector"]:  # type: ignore[index]
        Z = frozenset(int(i) for i in row["Z"])  # type: ignore[index]
        selector[Z] = int(row["p"])  # type: ignore[index]
    return selector


def direction(
    t: int,
    c: int,
    w: State,
    m: int,
    selector: Mapping[FrozenSet[int], int],
    offsets: Mapping[int, int],
) -> int:
    if t == NONCONST_LAYER:
        Zc = shift_set(zero_set(w, m), c)
        return (selector[Zc] + c) % D
    return (c + offsets[t]) % D


def is_perm(values: Sequence[int]) -> bool:
    return len(values) == len(set(values)) and min(values, default=0) == 0 and max(values, default=-1) == len(values) - 1


def is_single_cycle(p: Sequence[int]) -> bool:
    n = len(p)
    if not is_perm(p):
        return False
    seen = [False] * n
    x = 0
    for _ in range(n):
        if seen[x]:
            return False
        seen[x] = True
        x = p[x]
    return x == 0 and all(seen)


def reconstruct_zero_case(case: Mapping[str, object], verbose: bool = True) -> Tuple[int, List[List[int]], Dict[int, int]]:
    """Verify the zero-set certificate and return reconstructed color returns."""
    m = int(case["m"])
    offsets = as_int_dict(case["constant_offsets"])  # type: ignore[arg-type]
    if NONCONST_LAYER in offsets:
        raise VerificationError(f"m={m}: non-constant layer appears in constant_offsets")
    expected_offset_layers = set(range(m)) - {NONCONST_LAYER}
    if set(offsets) != expected_offset_layers:
        raise VerificationError(f"m={m}: constant_offsets keys are {sorted(offsets)}, expected {sorted(expected_offset_layers)}")

    selector = load_selector(case)
    states = root_states(m)
    idx = {w: i for i, w in enumerate(states)}
    n = len(states)

    encountered = {zero_set(w, m) for w in states}
    missing = encountered - set(selector)
    if missing:
        sample = ", ".join(str(sorted(z)) for z in sorted(missing, key=lambda z: (len(z), sorted(z)))[:8])
        raise VerificationError(f"m={m}: selector missing zero-sets, e.g. {sample}")

    # RF1 row Latin condition for the non-constant layer.
    for w in states:
        row = [direction(NONCONST_LAYER, c, w, m, selector, offsets) for c in range(D)]
        if sorted(row) != list(range(D)):
            raise VerificationError(f"m={m}: non-Latin row at w={w}: {row}")

    # Incoming exact-cover condition MC_7 for color 0; equivariance gives all colors.
    for y in states:
        hits = []
        for i in range(D):
            pred = add_q(y, i, m, sign=-1)
            if selector[zero_set(pred, m)] == i:
                hits.append(i)
        if len(hits) != 1:
            raise VerificationError(f"m={m}: MC_7 fails at y={y}, hits={hits}")

    # Layer maps P_{t,c}.
    layer_maps: List[List[List[int]]] = []
    for t in range(m):
        by_color: List[List[int]] = []
        for c in range(D):
            arr = [idx[add_q(w, direction(t, c, w, m, selector, offsets), m)] for w in states]
            if not is_perm(arr):
                raise VerificationError(f"m={m}: layer map is not bijective at t={t}, color={c}")
            by_color.append(arr)
        layer_maps.append(by_color)

    # Return maps R_c=P_{m-1,c}...P_{0,c}; also directly enumerate one-cycle property.
    returns: List[List[int]] = []
    for c in range(D):
        ret = list(range(n))
        for t in range(m):
            f = layer_maps[t][c]
            ret = [f[x] for x in ret]
        one_cycle = is_single_cycle(ret)
        if verbose:
            print(f"m={m}, color={c}: return single cycle = {one_cycle}, length target={n}")
        if not one_cycle:
            raise VerificationError(f"m={m}, color={c}: return map is not a single {n}-cycle")
        returns.append(ret)

    if verbose:
        print(f"m={m}: zero-set schedule verified, root states={n}, torus Hamilton length={m*n}")
    return m, returns, offsets


def verify_rank_case(
    m: int,
    zero_offsets: Mapping[int, int],
    reconstructed_returns: Sequence[Sequence[int]],
    rank_case: Mapping[str, object],
    verbose: bool = True,
) -> None:
    """Verify the rank-coordinate certificate against reconstructed returns."""
    if int(rank_case.get("m", -1)) != m:
        raise VerificationError(f"m={m}: rank metadata has m={rank_case.get('m')}")
    if int(rank_case.get("dimension", -1)) != D:
        raise VerificationError(f"m={m}: rank metadata dimension is {rank_case.get('dimension')}, expected {D}")

    n = len(reconstructed_returns[0])
    if int(rank_case.get("num_states", -1)) != n:
        raise VerificationError(f"m={m}: rank num_states={rank_case.get('num_states')}, expected {n}")

    rank_offsets = as_int_dict(rank_case.get("constant_offsets", {}))  # type: ignore[arg-type]
    if rank_offsets != dict(zero_offsets):
        raise VerificationError(f"m={m}: rank constant_offsets {rank_offsets} do not match zero-set offsets {dict(zero_offsets)}")

    raw_ranks = rank_case.get("ranks")
    if not isinstance(raw_ranks, Mapping):
        raise VerificationError(f"m={m}: rank certificate has no ranks object")

    raw_return_maps = rank_case.get("return_maps")
    stored_maps: Optional[Mapping[str, object]] = raw_return_maps if isinstance(raw_return_maps, Mapping) else None

    for c in range(D):
        key = str(c)
        if key not in raw_ranks:
            raise VerificationError(f"m={m}, color={c}: missing rank list")
        ranks = [int(v) for v in raw_ranks[key]]  # type: ignore[index]
        if len(ranks) != n:
            raise VerificationError(f"m={m}, color={c}: rank length {len(ranks)}, expected {n}")
        rank_perm = is_perm(ranks)
        if not rank_perm:
            raise VerificationError(f"m={m}, color={c}: rank list is not a permutation of 0..{n-1}")

        ret = list(int(v) for v in reconstructed_returns[c])
        stored_match = None
        if stored_maps is not None:
            if key not in stored_maps:
                raise VerificationError(f"m={m}, color={c}: stored return_maps missing color")
            stored = [int(v) for v in stored_maps[key]]  # type: ignore[index]
            if len(stored) != n:
                raise VerificationError(f"m={m}, color={c}: stored return map length {len(stored)}, expected {n}")
            stored_match = stored == ret
            if not stored_match:
                raise VerificationError(f"m={m}, color={c}: stored return map does not match reconstructed return map")

        bad_at = None
        for i, j in enumerate(ret):
            if ranks[j] != (ranks[i] + 1) % n:
                bad_at = (i, j, ranks[i], ranks[j])
                break
        if bad_at is not None:
            i, j, ri, rj = bad_at
            raise VerificationError(
                f"m={m}, color={c}: rank increment fails at state index {i}: "
                f"R(i)={j}, rank(i)={ri}, rank(R(i))={rj}, expected {(ri + 1) % n}"
            )

        if verbose:
            suffix = f", stored return map match = {stored_match}" if stored_match is not None else ""
            print(f"m={m}, color={c}: rank permutation = True, rank increment = True{suffix}")

    if verbose:
        print(f"m={m}: rank certificate verified")


def load_json(path: Path) -> Mapping[str, object]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # pragma: no cover - diagnostic path
        raise VerificationError(f"could not read JSON file {path}: {exc}") from exc


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify D7(m), m=3,5, zero-set and optional rank certificates.")
    parser.add_argument(
        "zero_set_certificate",
        nargs="?",
        default="d7_m3_m5_zero_set_certificates.json",
        help="zero-set certificate JSON",
    )
    parser.add_argument(
        "rank_certificate",
        nargs="?",
        default=None,
        help="optional rank-certificate JSON; when supplied, checks rank increment predicates",
    )
    parser.add_argument("--rank-certificate", dest="rank_certificate_opt", help="rank-certificate JSON, alternative to positional argument")
    parser.add_argument("--m", choices=["3", "5"], help="verify only one modulus")
    parser.add_argument("--skip-rank", action="store_true", help="ignore any supplied rank certificate")
    parser.add_argument("--quiet", action="store_true", help="suppress per-color success messages")
    args = parser.parse_args()

    zero_path = Path(args.zero_set_certificate)
    rank_arg = args.rank_certificate_opt or args.rank_certificate
    rank_path = Path(rank_arg) if rank_arg and not args.skip_rank else None
    verbose = not args.quiet

    try:
        zero_data = load_json(zero_path)
        zero_cases = zero_data.get("certificates")
        if not isinstance(zero_cases, Mapping):
            raise VerificationError("zero-set file has no certificates object")

        rank_cases = None
        if rank_path is not None:
            rank_data = load_json(rank_path)
            rank_cases = rank_data.get("certificates")
            if not isinstance(rank_cases, Mapping):
                raise VerificationError("rank file has no certificates object")

        keys = [args.m] if args.m else sorted(zero_cases.keys(), key=int)
        for key in keys:
            if key not in zero_cases:
                raise VerificationError(f"zero-set file missing case m={key}")
            m, returns, offsets = reconstruct_zero_case(zero_cases[key], verbose=verbose)  # type: ignore[index]
            if rank_cases is not None:
                if key not in rank_cases:
                    raise VerificationError(f"rank file missing case m={key}")
                verify_rank_case(m, offsets, returns, rank_cases[key], verbose=verbose)  # type: ignore[index]

        if verbose:
            if rank_cases is None:
                print("ALL REQUESTED ZERO-SET CHECKS PASSED")
            else:
                print("ALL REQUESTED ZERO-SET AND RANK CHECKS PASSED")
    except VerificationError as exc:
        print(f"ERROR: {exc}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
